export type TabType =
  | 'home'
  | 'donations'
  | 'beneficiaries'
  | 'members'
  | 'users'
  | 'settings'
  | 'statement'
  | 'sms-logs';

export interface SmsLog {
  id: string;
  recipient: string;
  message: string;
  type: string;
  status: string;
  timestamp: string;
  response?: string;
}

export interface Donation {
  id: string;
  Date: string;
  'Donor Name': string;
  'NIC No': string;
  'Contact No': string;
  'Permanent Address': string;
  Profession: string;
  Amount: number;
  'Transaction ID': string;
  Remarks: string;
  EnteredBy: string;
  Category?: string;
  ProofImage?: string;
  Status?: 'Approved' | 'Pending' | 'Rejected';
  SubmittedAt?: string;
  ApprovedBy?: string;
  ApprovedAt?: string;
  RejectionReason?: string;
  DonorEmail?: string;
  Source?: 'Audit' | 'Live';
  SendSms?: boolean;
  SmsSent?: boolean;
  SmsMessageId?: string;
  [key: string]: any;
}

export interface Beneficiary {
  id: string;
  Date: string;
  'Beneficiary Name': string;
  'Father Name': string;
  'NIC No': string;
  'Contact No': string;
  'Permanent Address': string;
  Profession: string;
  Purpose: string;
  Amount: number;
  'Transaction ID': string;
  Remarks: string;
  VerifiedBy?: string;
  ProofLink?: string;
  Status?: 'Allotted' | 'Pending' | 'Verified';
  Source?: 'Audit' | 'Live';
  SendSms?: boolean;
  [key: string]: any;
}

export interface Member {
  id: string;
  Name: string;
  'Father Name': string;
  Designation: string;
  'N.I.C No': string;
  Address: string;
  'Contact No': string;
  'Joining Date': string;
  'Expiry Date': string;
  Remarks: string;
  NICImage?: string;
  NICImageBack?: string;
  Source?: 'Audit' | 'Live';
}

export interface UserAccount {
  id: string;
  username: string;
  password?: string;
  Rights: 'Admin' | 'Checker' | 'Operator' | 'Viewer';
  Access: string[]; // e.g. ['Home', 'Donations', 'Beneficiaries', 'Members', 'Users', 'Settings', 'Statement', 'SwdoMembers']
  Theme: 'Dark' | 'Light';
  Source?: 'Audit' | 'Live';
}

export interface PortalSettings {
  'Foundation Name': string;
  SubTitle: string;
  Address: string;
  Chairperson: string;
  Secretary: string;
  Treasurer: string;
  'Easypaisa No': string;
  'Easypaisa Title': string;
  'Bank No': string;
  'Bank Title': string;
  'Bank Account No'?: string;
  'Account Title'?: string;
  Currency: string;
  TreasurerSignature?: string;
  ChairpersonSignature?: string;
  AutoSmsSubmission?: boolean;
  AutoSmsApproval?: boolean;
  AutoSmsBeneficiary?: boolean;
  VeevoSmsHash?: string;
  VeevoSenderNum?: string;
  SmsSubmissionTemplate?: string;
  SmsApprovalTemplate?: string;
  SmsBeneficiaryTemplate?: string;
}

export interface ToastMessage {
  id: string;
  type: 'success' | 'error' | 'info';
  message: string;
}
